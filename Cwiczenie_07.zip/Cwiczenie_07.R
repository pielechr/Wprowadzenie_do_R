################################################
#                                              #
#      WPROWADZENIE DO ANALIZY DANYCH W R      #
#      2025/26                                 #
#      Remigiusz Pielech                       #
#                                              #
#      Cwiczenie #7 -  2.12.2025               #
#                                              #
################################################

## Pakiety

library(tidyverse)

## 0. Wczytywanie danych

drapiezniki <- read_delim("https://raw.githubusercontent.com/pielechr/Wprowadzenie_do_R/refs/heads/main/drapiezniki.csv")
spec_list <- read_csv("https://raw.githubusercontent.com/pielechr/Wprowadzenie_do_R/refs/heads/main/species_list.csv") 
traits <- read_csv("https://raw.githubusercontent.com/pielechr/Wprowadzenie_do_R/refs/heads/main/traits.csv")
nazwy_gat <- read_csv("https://raw.githubusercontent.com/pielechr/Wprowadzenie_do_R/refs/heads/main/drzewa.csv")  

## 1. tidyverse - czesc III

## 1.1 leftjoin() - kompletne polaczenie

spec_list
nazwy_gat

# przypisujemy nazwy polskie z tabeli `nazwy_gat` do istniejacej tabeli `spec_list`
# znajdujemy zmienne, ktore lacza obie tabele (key) - beda to zmienne zawierajace nazwy naukowe

spec_list %>% 
  left_join(nazwy_gat,
            join_by(species == nazwa_naukowa))


## 1.2 left_join()

trees <- spec_list %>% 
  left_join(nazwy_gat,
            join_by(species == nazwa_naukowa)) %>% 
  select(plot_id, species, nazwa_polska, abundance) %>% 
  arrange(species, desc(abundance))

trees

traits

trees %>% 
  left_join(traits, by = "species") # w tym przypadku mozemy nawet pominac argument `by =`








?left_join

library(dplyr)
library(readr)

set.seed(1)

# 1A. Lista gatunków drzew (30 obs.) + cechy funkcjonalne

species_pool <- c("Quercus robur","Betula pendula","Picea abies",
                  "Pinus sylvestris","Fagus sylvatica","Acer platanoides",
                  "Carpinus betulus","Alnus glutinosa","Abies alba")

species_list <- tibble(
  plot_id = sample(1:10, 30, replace = TRUE),
  species = sample(species_pool, 30, replace = TRUE),
  abundance = sample(1:50, 30, replace = TRUE)
)

traits <- tibble(
  species = c("Quercus robur","Betula pendula","Alnus glutinosa",
              "Pinus sylvestris","Carpinus betulus"),
  SLA = c(15.2,18.4,21.1,10.7,16.5),
  leaf_N = c(2.1,1.9,2.4,1.4,2.0)
)

write_csv(species_list, "species_list.csv")
write_csv(traits, "traits.csv")

left_join(species_list, traits, by="species")


# 1B. Metadane powierzchni (30 obs.) + presja zgryzania

plots <- tibble(
  plot_id = 1:30,
  forest_type = sample(c("Beech","Oak-hornbeam","Spruce","Pine"), 30, replace = TRUE)
)

browsing <- tibble(
  plot_id = c(3,5,7,12,18,21,25),
  browsing_pressure = c("Low","Medium","High","High","Medium","Low","High")
)

write_csv(plots, "plots.csv")
write_csv(browsing, "browsing.csv")

left_join(plots, browsing, by="plot_id")



library(dplyr)
library(readr)

# Tabela gatunków drapieżnych w Polsce — lista podstawowa
carnivores_pl <- tibble(
  latin = c(
    "Canis lupus",             # wilk  
    "Lynx lynx",               # ryś euroazjatycki  
    "Ursus arctos",            # niedźwiedź brunatny  
    "Vulpes vulpes",           # lis rudy  
    "Nyctereutes procyonoides",# jenot (introdukowany)  
    "Felis silvestris",        # żbik / kot leśny  
    "Martes martes",           # kuna leśna  
    "Martes foina",            # kuna domowa  
    "Meles meles",             # borsuk europejski  
    "Mustela erminea",         # gronostaj  
    "Mustela nivalis",         # łasica pospolita  
    "Mustela putorius",        # tchórz zwyczajny  
    "Lutra lutra"              # wydra europejska  
    # Można po rozszerzeniu: Mustela eversmanii, Neovison vison, Procyon lotor, etc.
  ),
  polish_name = c(
    "wilk szary",
    "ryś euroazjatycki",
    "niedźwiedź brunatny",
    "lis rudy",
    "jenot",
    "żbik",
    "kuna leśna",
    "kuna domowa",
    "borsuk europejski",
    "gronostaj europejski",
    "łasica pospolita",
    "tchórz zwyczajny",
    "wydra europejska"
  )
)

# Status ochrony prawnej w Polsce — na podstawie aktualnych list ochrony gatunkowej
protection_status <- tibble(
  latin = c(
    "Canis lupus","Lynx lynx","Ursus arctos",
    "Vulpes vulpes","Nyctereutes procyonoides",
    "Felis silvestris","Martes martes","Martes foina",
    "Meles meles","Mustela erminea","Mustela nivalis",
    "Mustela putorius","Lutra lutra"
  ),
  protection_pl = c(
    "ścisła",    # wilk :contentReference[oaicite:4]{index=4}
    "ścisła",    # ryś :contentReference[oaicite:5]{index=5}
    "ścisła",    # niedźwiedź :contentReference[oaicite:6]{index=6}
    NA,          # lis — zwykle bez ochrony prawnej jako drapieżnik pospolity (nie na liście ścisłej) :contentReference[oaicite:7]{index=7}
    NA,          # jenot – inwazyjny/introdukowany, brak ochrony (z reguły)  
    "ścisła",    # żbik / kot leśny — często pod ochroną, ale wymaga weryfikacji  
    NA,          # kuna leśna — zazwyczaj bez ochrony specjalnej  
    NA,          # kuna domowa  
    NA,          # borsuk — bez ochrony specjalnej (zwykle)  
    "częściowa", # gronostaj — wymieniony w ochronie częściowej w polskich listach :contentReference[oaicite:8]{index=8}  
    "częściowa", # łasica pospolita — zgodnie z listą ochrony częściowej :contentReference[oaicite:9]{index=9}  
    NA,          # tchórz zwyczajny — wymaga sprawdzenia  
    "częściowa"  # wydra — wymieniona jako objęta częściową ochroną w jednej z list :contentReference[oaicite:10]{index=10}
  )
)

# Tabela wynikowa — połączenie
carnivores <- carnivores_pl %>%
  left_join(protection_status, by = "latin") %>%
  mutate(
    red_list_pl = NA_character_,    # krajowa Czerwona Lista — do uzupełnienia
    red_book_pl = NA_character_     # Polska Czerwona Księga Zwierząt — do uzupełnienia
  )

# Zapis do CSV
write_csv(carnivores, "polish_carnivores_full.csv")

carnivores

